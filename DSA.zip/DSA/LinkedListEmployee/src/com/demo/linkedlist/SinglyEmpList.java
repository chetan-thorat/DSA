package com.demo.linkedlist;

import java.util.Scanner;

import com.demo.beans.Employee;
import com.demo.linkedlist.SinglyEmpList.Node;

public class SinglyEmpList extends Employee{
	
	
	Node head;
	static private Employee emp;
	
	class Node{
		private Employee emp;
		Node next;
		
		public Node(){
			this.emp = new Employee();
			this.next=null;
		}
		public Node(Employee emp) {
			this.emp=emp;
		}
	}
	
	//Defalut Constructor
	public SinglyEmpList(){
		head = null;
	}
	
	
	Scanner sc = new Scanner(System.in);
	
	//Add employee 
	public void addEmp() {
		
		Node temp = head;
		System.out.println("Enter id");
		int id = sc.nextInt();
		
		System.out.println("Enter name");
		String name = sc.next();
		
		emp = new Employee(id,name);
		Node newNode =  new Node(emp);
		if(head==null) {
			head=newNode;
		}
		else {
			while(temp.next!=null) {
				temp=temp.next;
			}
			temp.next=newNode;
		}
		
		
		
	}
	public void addAtBegin() {
		Node temp = head;
		System.out.println("Enter id");
		int id = sc.nextInt();
		
		System.out.println("Enter name");
		String name = sc.next();
		
		emp = new Employee(id,name);
		Node newNode=new Node(emp);
		
		newNode.next=temp;
		head=newNode;
		
		
		
	}
	public void addById(int uid) {
		Node temp = head;
		Node prev=null;
		System.out.println("Enter id");
		int id= sc.nextInt();
		
		System.out.println("Enter name");
		String name = sc.next();
		
		emp = new Employee(id,name);
		Node newNode=new Node(emp);
		
		while(uid!=temp.emp.getId()) {
			prev=temp;
			temp=temp.next;
		}
		if(uid==temp.emp.getId()) {
		newNode.next=temp.next;
		temp.next=newNode;
		}
		else {
			System.out.println("ID not found");
		}
	}
	
	//display employee
	public void displayEmp() {
		Node temp = head;
		while(temp!=null) {
			System.out.print(temp.emp+",  ");
			temp=temp.next;
		}
		System.out.println();
		
	}
	
	
	
}
