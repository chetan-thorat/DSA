package com.demo.test;

import com.demo.linkedlist.SinglyEmpList;

public class TestEmp {

	public static void main(String[] args) {
		SinglyEmpList sl = new SinglyEmpList();
		sl.addEmp();
		sl.addEmp();
		sl.addEmp();
		sl.displayEmp();
		
		
//		sl.addAtBegin();
//		sl.displayEmp();
		
		
		sl.addById(2);
		sl.displayEmp();
		
		
	}

}
