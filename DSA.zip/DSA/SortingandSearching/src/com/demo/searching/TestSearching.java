package com.demo.searching;

public class TestSearching {

	public static void main(String[] args) {
		SearchingClass ts=new SearchingClass();
		int[] arr= {1,23,45,65,85,89,101};
		int x=85;
		
//		int i=ts.seqSearch(arr,x);
//		if(i==-1)
//			System.out.println("number not found");
//		else
//			System.out.println(ts.seqSearch(arr,x));
//		int low = 0;
//		int high = arr.length-1;
//		
//		System.out.println(ts.binarySearch(arr, low, high, x));
		System.out.println(ts.binarySearchNoRecurr(arr, x));
		
		
		
	}

	

}
