package com.demo.sorting;

public class TestSelection {

	public static void main(String[] args) {
		int[] arr= {14,2,334,85,67,1,3,15,5,4,7};
		SelectionSort ss = new SelectionSort();
		ss.selectionSortNthMax(arr,2);

	}

}
