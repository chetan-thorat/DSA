package com.demo.sorting;

import java.util.Arrays;

public class TestHeapSort {

	public static void main(String[] args) {
		int[] arr = {6,12,2,26,8,18,21,9,5};
		HeapSortAlgorithm.heapSort(arr);
		
		

	}

}
