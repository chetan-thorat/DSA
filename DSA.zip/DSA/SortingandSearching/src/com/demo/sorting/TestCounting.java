package com.demo.sorting;

import java.util.Arrays;

public class TestCounting {

	public static void main(String[] args) {
		int[] arr= {9,1,7,1,2,3,3,4,4};
		System.out.println(Arrays.toString(CountingSort.countSort(arr))); 

	}

}
