package com.demo.sorting;

import java.util.Arrays;

public class BubbleSort {
	
	int[] arr={2,37,3,8843,12,85,1,92,7,334,0};
	
	public void bubbleSort() {
		boolean flag=false;
		for(int j=0;j<arr.length;j++) {
			flag=false;
			int temp=arr[0];
			for(int i=1;i<arr.length-j;i++) {
				if(arr[i]>arr[i-1]) {
					temp=arr[i];
					flag=true;
				}else {
					arr[i-1]=arr[i];
					arr[i]=temp;
					flag=true;
				}
		}
		
		if(flag==false) {
			break;
		}
		System.out.println(Arrays.toString(arr));
	}

	
	}
	@Override
	public String toString() {
		return "BubbleSort [arr=" + Arrays.toString(arr) + "]";
	}
}
