package com.demo.sorting;

import java.util.Arrays;

public class CountingSort {
	
	public static int[] countSort(int[] arr) {
		//find the max element from the array
		int max=findMax(arr);
		System.out.println(max);
		//create max element size array
		int[] count = new int[max+1];
		
		//Initialization of 0 to all elements
		for(int i=0;i<count.length;i++) {
			count[i]=0;
		}
		
		System.out.println(Arrays.toString(count));
		//add count of individual elements in count array
		for(int i=0;i<arr.length;i++) {
			count[arr[i]]++;
		}
		System.out.println(Arrays.toString(count));
		
		
		// find cumulative sum
		for(int i=1;i<count.length;i++) {
			count[i] = count[i-1]+count[i];
		}
		System.out.println(Arrays.toString(count));
		
		int[] output = new int[arr.length];
		
		for(int i=0;i<arr.length;i++) {
			int pos = count[arr[i]]-1;
			output[pos]=arr[i];
			count[arr[i]]--;
		}
		
		return output;
	}
	
	public static int findMax(int[] arr) {
		int max = arr[0];
		for(int i=0;i<arr.length;i++) {
			if(arr[i]>max) {
				max=arr[i];
			}
		}
		return max;
	}
}
