package com.demo.sorting;

import java.util.Arrays;

public class TestMergeSort {

	public static void main(String[] args) {
		int[] arr= {5,7,3,10,6,4};
		MergeSort.mergeSort(arr, 0,arr.length-1);
		System.out.println("final array : "+Arrays.toString(arr));


	}

}
