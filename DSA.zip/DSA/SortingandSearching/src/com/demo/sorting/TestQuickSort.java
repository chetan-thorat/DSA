package com.demo.sorting;

import java.util.Arrays;

public class TestQuickSort {

	public static void main(String[] args) {
		int[] arr= {19,120,1,2,3,44,55};
		
		QuickSortAlgorithm.quickSort(arr, 0, arr.length-1);
		System.out.println(Arrays.toString(arr));
	}

}
