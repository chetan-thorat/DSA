package com.demo.sorting;

import java.util.Arrays;

public class SelectionSort {
	
	public int findMin(int[] arr,int start,int end) {
		int minidx = start;
		int min=arr[start];
		for(int i=start+1;i<arr.length;i++) {
			if(arr[i]<min) {
				min=arr[i];
				minidx=i;
			}
		}
		return minidx; 
	}
	
	public int findMax(int[] arr,int start,int end) {
		int maxidx = start;
		int max=arr[start];
		for(int i=start+1;i<arr.length;i++) {
			if(arr[i]>max) {
				max=arr[i];
				maxidx=i;
			}
		}
		return maxidx; 
	}

	
	public void selectionSort(int[] arr) {
		for(int i=0; i<arr.length-1;i++) {
			
			int minidx = findMin(arr,i,arr.length);
			
			int temp=arr[i];
			arr[i]=arr[minidx];
			arr[minidx]=temp;
			
			System.out.println(Arrays.toString(arr));
		}
		
		
	}
	public void selectionSortDesc(int[] arr) {
		for(int i=0; i<arr.length-1;i++) {
			
			int maxidx = findMax(arr,i,arr.length);
			
			int temp=arr[i];
			arr[i]=arr[maxidx];
			arr[maxidx]=temp;
			
			System.out.println(Arrays.toString(arr));
		}
	}
	
	
	public void selectionSortNthMax(int[] arr, int n) {
		int i;
		
		for(i=0; i<n;i++) {
			
			int maxidx = findMax(arr,i,arr.length);
			
			if(i==n-1) {
				System.out.println(arr[maxidx]);
				break;
			}
			int temp=arr[i];
			arr[i]=arr[maxidx];
			arr[maxidx]=temp;
		
		}
		
	}
	
	
}
