package com.demo.sorting;

import java.util.Arrays;

public class TestBubble {

	public static void main(String[] args) {
			
			BubbleSort bs=new BubbleSort();
			
			
			bs.bubbleSort();
			
	}

}