package com.demo.sorting;

import java.util.Arrays;

public class TestInsertionSort {

	public static void main(String[] args) {
		int[] arr= {3,7,8,9,1,2};
		
		InsertionSort.insertionSort(arr); 
	}

}
