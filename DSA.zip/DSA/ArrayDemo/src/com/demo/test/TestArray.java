package com.demo.test;

import java.util.Arrays;

import com.demo.beans.MyArray;

public class TestArray {

	public static void main(String[] args) {
		
		MyArray mr = new MyArray(7);
		
		
		
		
		//mr.findMax();
		
		//mr.reverseArray();
		
		//mr.rightSideRotate(3);
		//System.out.println(Arrays.toString(mr.leftSideRotate(3)));
		
		
//		mr.replaceIndexValue();
		
	}

}
