package com.demo.test;

import java.util.Arrays;

import com.demo.beans.My2DArray;

public class TestMy2DArray {
    public static void main(String[] args) {
    	My2DArray ob= new My2DArray(5,5);
    	ob.addValue();
    	
    	System.out.println(Arrays.toString(ob.sum()));
    	
    	
    }
}
