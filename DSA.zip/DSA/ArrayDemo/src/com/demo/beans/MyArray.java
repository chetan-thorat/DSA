package com.demo.beans;

import java.util.Arrays;
import java.util.Scanner;

public class MyArray {
	private int[] arr;
	
	Scanner sc = new Scanner(System.in);
	public MyArray() {
		arr = new int[5];
		
	}
	
	public MyArray(int n) {
		arr = new int[n];
		
	}
	
	
	//Find maximum number
	public int findMax() {
		int max = arr[0];
		for(int i=0;i<arr.length;i++) {
			if(max<arr[i]) {
				max=arr[i];
			}
		}	
		return max;
	}
	
	//Insert elements
	public void insertElements() {
		for(int i=0;i<arr.length;i++) {
			System.out.println("Enter "+i+"th element: ");
			arr[i]=sc.nextInt();
		}
	}
	
	
	//Reverse Array
	 public int[] reverseArray() {
		 
		 //1st way to create copy array
		 int[] arr2 = new int[arr.length];
		 for(int i=0,j=arr.length-1; i<arr.length;i++,j--) {
			 arr2[i]=arr[j];
		 }
		 return arr2;
	 }
		 
		 
		 
		 //2nd way using same array
//		 for(int i=0,j=arr.length-1;i<j;i++,j--) {
//			 int temp;
//			 temp=arr[i];
//			 arr[i]=arr[j];
//			 arr[j]=temp;	 	 
//		 }
//		 System.out.println(Arrays.toString(arr));	 
//	 }
	 
	 //RightSide rotate array function
	 public int[] rightSideRotate(int n) {
		 int temp;
		 if(n<arr.length) {
			 for(int i=0;i<n;i++) {
				 temp = arr[0];
				 for(int j=1;j<arr.length;j++) {
					 arr[j-1] = arr[j];
				 }
				 arr[arr.length-1]=temp;
				 System.out.println(i+1+"th rotataiton----->"+Arrays.toString(arr));
				
			 }
		 }
		 return arr;
	 }
	 
	 //LeftSide rotate array function
	 public int[] leftSideRotate(int n) {
		 int temp;
		 if(n<arr.length) {
			 for(int i=0;i<n;i++) {
				 temp = arr[arr.length-1];
				 for(int j=arr.length-1;j>0;j--) {
					 arr[j] = arr[j-1];
				 }
				 arr[0]=temp;
				 System.out.println(i+1+"th rotataiton----->"+Arrays.toString(arr));
				
			 }
		 }
		 return arr;
	 }
	 
	 
	 // find max number then create new array of size max number and put index at value'th location
	 public void replaceIndexValue() {
		 int maxNum = findMax();
		 int[] myArray = new int[maxNum+1];
		
		 
		 //to give all index value is -1
		 for(int i=0;i<myArray.length;i++) {
			 myArray[i]=-1;
		 }
		 
		 //put index at value'th location function
		 for(int i=0;i<arr.length;i++) {
			 myArray[arr[i]]=i;
			 System.out.println(Arrays.toString(myArray));
		 }
		 
		 System.out.println("----------------------");
		System.out.println(Arrays.toString(myArray));
		 
	 }
	 
	 
	 
	//to String method
	@Override
	public String toString() {
		return "MyArray [arr=" + Arrays.toString(arr) + "]";
	}
}
