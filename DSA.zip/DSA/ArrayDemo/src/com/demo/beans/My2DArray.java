package com.demo.beans;
import java.util.Arrays;
import java.util.Scanner;

public class My2DArray {
	private int[] [] arr1;
	private int [][] arr2;

	public My2DArray() {
		arr1=new int [3][3];
		arr2=new int [3][3];
	}
	public My2DArray(int i,int j) {
		arr1=new int[i][j];
		arr2=new int[i][j];
	}
	Scanner sc=new Scanner(System.in); 
	
	public void addValue() {
		System.out.println("enter values for array 1");
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				System.out.println("arr1 ["+i+"]"+"["+j+"]" +"vlues: ");
				arr1[i][j]=sc.nextInt();
			}
			}
			System.out.println("Enter Values for array 2");
			
			for(int i=0;i<3;i++){
				for(int j=0;j<3;j++)
				{
					System.out.println("arr1["+i+"]"+"["+j+"]"+"values: ");
					arr2[i][j]=sc.nextInt();
				}
			}
		}
public int[][] sum(){
	int[][] finalarr=new int[3][3];
	for(int i=0;i<3;i++) {
		for(int j=0;j<3;j++) {
		finalarr[i][j]=arr1[i][j]+arr2[i][j];
		}
	}
	return finalarr;
}
@Override
public String toString() {
	return "My2DArray [arr1=" + Arrays.toString(arr1) + ", arr2=" + Arrays.toString(arr2) + "]";
}
}

