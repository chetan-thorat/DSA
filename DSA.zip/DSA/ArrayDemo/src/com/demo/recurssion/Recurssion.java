package com.demo.recurssion;

public class Recurssion {
	public int add(int i) {
		if(i==1) {
			return 1;
		}
		
		return add(i-1) + i;
		
	}




	public int factorial(int i) {
		if(i==1) {
			return 1;
		}
		
		return factorial(i-1)*i;
		
	}
}
