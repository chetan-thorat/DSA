package com.demo.recurssion;

public class TestRecur {

	public static void main(String[] args) {
		Recurssion re = new Recurssion();
		System.out.println(re.factorial(5));

	}

}
