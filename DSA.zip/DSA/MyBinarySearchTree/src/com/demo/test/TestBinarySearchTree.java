package com.demo.test;

import com.demo.trees.MyBinarySearchTree;

public class TestBinarySearchTree {

	public static void main(String[] args) {
		MyBinarySearchTree bst = new MyBinarySearchTree();
		
		int[] arr = {22,44,3,23,5,7,1,26,68};
		for(int i=0; i<arr.length;i++) {
			bst.insertNode(arr[i]);
		}
		
		bst.inOrder();
		bst.preOrder();
		bst.postOrder();
		System.out.println(bst.search(44));
		System.out.println(bst.searchNonRecurssive(44));
		
	}

}
