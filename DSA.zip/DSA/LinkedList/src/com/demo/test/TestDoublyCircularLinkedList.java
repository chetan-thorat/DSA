package com.demo.test;

import com.demo.LinkedList.DoublyCircularLinkedList;

public class TestDoublyCircularLinkedList {

	public static void main(String[] args) {
		DoublyCircularLinkedList dbl = new DoublyCircularLinkedList();
		dbl.addData(10);
		dbl.addData(20);
		dbl.addData(30);
		dbl.addData(40);
		dbl.addData(10);
		dbl.addData(20);
		dbl.addData(30);
		dbl.addData(40);
		dbl.displayData();
//		dbl.addByPosition(2, 50);
//		dbl.displayData();
//		
		
	dbl.reverseList();

	//	dbl.addElements();
	}

}
