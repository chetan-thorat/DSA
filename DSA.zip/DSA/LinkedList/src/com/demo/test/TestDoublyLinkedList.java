package com.demo.test;

import com.demo.LinkedList.DoublyLinkedList;

public class TestDoublyLinkedList {
	public static void main(String[] args) {
		DoublyLinkedList dbl=new DoublyLinkedList();
		dbl.addData(10);
		dbl.addData(20);
		dbl.addData(30);
		dbl.addData(40);
		dbl.addData(50);
		dbl.displayData();
//		
		dbl.addByValue(100, 30);
		dbl.displayData();
		dbl.displayDataReverse();
		
		dbl.deleteByValue(100);
		dbl.displayData();
		//System.out.println(dbl.sumElements());	
	}
}
