package com.demo.test;

import com.demo.LinkedList.SinglyLinkedList;

public class TestSinglyLinkedList {

	public static void main(String[] args) {
		SinglyLinkedList sl = new SinglyLinkedList();
		sl.addNode(10);
		sl.addNode(20);
		sl.addNode(30);
		sl.addNode(40);
		sl.addNode(50);
		sl.addNode(60);
		
		
	
//		sl.deleteByPosition(6);
		sl.displayData();
		
//		sl.addDataAtBegin(50);
//		sl.displayData();
//		
//		sl.addInBetween(10,60);
//		sl.displayData();
	}

}
