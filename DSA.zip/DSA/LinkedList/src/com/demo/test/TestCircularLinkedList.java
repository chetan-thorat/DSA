package com.demo.test;

import com.demo.LinkedList.CircularLinkedList;

public class TestCircularLinkedList {

	public static void main(String[] args) {
		CircularLinkedList cl = new CircularLinkedList();
		cl.addData(10);
		cl.addData(20);
		cl.addData(30);
		cl.displayData();
		cl.addByPosition(1, 50);
		cl.displayData();
		
		cl.deleteByPosition(3);
		cl.displayData();
		cl.sumValues();
		
	}

}
