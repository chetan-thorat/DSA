package com.demo.LinkedList;

public class DoublyCircularLinkedList {
	Node head;
	class Node{
		int data;
		Node next;
		Node prev;
		
		public Node(int val) {
			this.data = val;
			this.next=null;
			this.prev=null;
		}
	}
	
	public void addData(int val) {
		
		Node newNode= new Node(val);
		if(head==null) {
			head=newNode;
			newNode.next=head;
			newNode.prev=head;
		}else {
			Node temp=head.prev;
			newNode.prev=temp;
			newNode.next=temp.next;
			temp.next=newNode;
			head.prev=newNode;
		}
	}
	
	
	public void addByPosition(int pos, int value) {
		if(head==null) {
			System.out.println("List is empty");
		}
		else {
			Node newNode=new Node(value);
			if(pos==1) {
				Node temp = head.prev;
				
				newNode.next=head;
				newNode.prev=temp;
				temp.next=newNode;
				head.prev=newNode;
				head=newNode;
			}
			else {
				Node temp=head;
				int count=0;
				for(int i=0;temp.next!=head && i<pos-2;i++) {
					temp=temp.next;
					count++;
				}
				if(count==pos-2) {
					newNode.next=temp.next;
					newNode.prev=temp;
					temp.next.prev=newNode;
					temp.next=newNode;
			
				}
			}
		}
	}
	
	
	public void deleteByPosition(int pos) {
		if(head==null) {
			System.out.println("list is empty");
		}
		else{
			
				if(pos==1) {
					Node temp=head;
				
				head.next.prev=head.prev;
				head.prev.next=head.next;
				head=head.next;
				temp.next=null;
				}
				else {
				Node temp=head;
				int count=0;
				for(int i=0;temp.next!=head && i<pos-1;i++) {
					temp=temp.next;
					count++;
					}
			if(count==pos-1) {
				temp.prev.next=temp.next;
				temp.next.prev=temp.prev;
				temp.next=null;
				temp.prev=null;
			}else {
				System.out.println("position out of bounds "+pos);
			}
		}
		}
	}
	
	
	public void displayData() {
		if(head==null) {
			System.out.println("list is empty");
		}else {
		Node temp=head;
		do {
			System.out.print(temp.data+",");
			temp=temp.next;
			
		}while(temp!=head);
		System.out.println();
		}
	}
	
	
	public void addElements() {
		int sumNum=0;
		if(head==null) {
			System.out.println("list is empty");
		}
		else {
			Node temp=head;
			do {
				sumNum = sumNum + temp.data;
				temp=temp.next;
			}while(temp!=head);
		}
		
		System.out.println(sumNum);
		
	}
	
	
	public void reverseList() {
		if(head==null) {
			System.out.println("list is empty");
		}
		
		else {
			Node temp=head.prev;
			
			while(temp!=head) {
				System.out.print(temp.data+", ");
				temp=temp.prev;
			}
			System.out.print(temp.data); ///just to print first element
		}
	}
}
