package com.demo.LinkedList;

public class CircularLinkedList {
	Node head;
	class Node{
		int data;
		Node next;
		
		public Node(int data) {
			super();
			this.data = data;
			this.next = null;
		}
	}
	public CircularLinkedList() {
		super();
		this.head = null;
	}
	
	public void addData(int val) {
		Node newNode= new Node(val);
		if(head==null) {
			head=newNode;
		}
		else {
			Node temp=head;
			while(temp.next!=head) {
				temp=temp.next;
			}
//			newNode.next=head;
//			head=newNode;
//			temp.next=newNode;
			temp.next=newNode;
			
			
		}
		newNode.next=head;
	}
	
	
	public void addByPosition(int pos,int value) {
		
		if(head==null) {
			System.out.println("list is empty");
		}
		
		else {
			Node newNode=new Node(value);
			Node temp=head;
			if(pos==1) {
				while(temp.next!=head) {
					temp=temp.next;
				}
				newNode.next=head;
				temp.next=newNode;
				head=newNode;
			}
			else {
				int count=0;
				for(int i=0;temp.next!=head && i<pos-2;i++) {
					temp=temp.next;
					count++;
				}
				
				if(count==pos-2) {
					newNode.next=temp.next;
					temp.next=newNode;
				}
			}
		}
	}
	
	
	public void deleteByPosition(int pos) {
		if(head==null) {
			System.out.println("List is empty");
		}
		else {
			if(pos==1) {
				Node temp=head;
				while(temp.next!=head) {
					temp=temp.next;
				}
				temp.next=head.next;
				head.next=null;
				head=temp.next;
			}
			else {
				Node temp=head;
				Node prev=null;
				int count=0;
				for(int i=0;temp.next!=head && i<pos-1;i++) {
					prev=temp;
					temp=temp.next;
					count++;
				}
				if(count==pos-1) {
					prev.next=temp.next;
					temp.next=null;
				}
				
			}
		}
	} 
	
	public void sumValues() {
		int sumNum = 0;
		if(head==null) {
			System.out.println("List is Empty");
		}
		else {
			Node temp=head;
			do {
				sumNum=sumNum+temp.data;
				temp=temp.next;
			}while(temp!=head);
		}
		System.out.println("total sum is :"+sumNum);
	}
	
	
	public void displayData() {
		if(head==null) {
			System.out.println("List is Empty");
		}
		else {
			Node temp=head;
			do {
				System.out.print(temp.data+", ");
				temp=temp.next;
			}while(temp!=head);
			System.out.println();
		}
		
	}
	
	
}
