package com.demo.LinkedList;

public class SinglyLinkedList {
	Node head;
	class Node{
		int data;
		Node next;
	
		
		public Node(int val){
			this.data = val;
			this.next=null;
		}
	}
	
	//Defalut Constructor
	public SinglyLinkedList(){
		head = null;
	}
	
	
	//Add data at end
	public void addNode(int val) {
		
		Node newNode = new Node(val);
		
		if(head==null) {
			head=newNode;
		}
		else {
			Node temp=head;
			
			while(temp.next!=null) {
				temp=temp.next;
			}
			temp.next=newNode;
		}
	}
	
	//Display all data
	public void displayData() {
		Node temp = head;
		if(head==null) {
			System.out.println("List is Empty");
		}
		
		else {
			
			while(temp!=null) {
				System.out.print(temp.data+", ");
				temp=temp.next;
			}
			System.out.println();
		}
	}
	
	
	//Add data from starting
	public void addDataAtBegin(int val) {
		
		Node newNode = new Node(val);
		if(head==null) {
			head=newNode;
		}
		else {
			Node temp = head;
			newNode.next=temp;
			head=newNode;
		}
		
	}
	
	// add data in between to values
	public void addInBetween(int i,int val) {
		Node newNode = new Node(val);
		if(head==null) {
			head=newNode;
		}
		else {
			Node temp = head;
			while(temp.next!=null && temp.data!=i) {
				temp=temp.next;	
			}
			if(temp.data==i) {
			newNode.next=temp.next;
			temp.next=newNode;
			}
			else {
				System.out.println("Value not found");
			}
		}
	}
	
	
	//DELETE Functions
	
	
	//delete data by value
	public void deleteByValue(int val) {
		Node temp = head;
		
		if(head.data==val) {
			head=temp.next;
			temp.next=null;
		}
		
		else 
		{
			Node newNode = new Node(val);
				Node prev = null;
				while(temp.data!=val) 
				{
					temp=temp.next;	
				}
				
				while(prev.next!=temp) 
				{
					prev=prev.next;
				}
				prev.next = temp.next;
				temp=temp.next;
			
			}
		}
	
	public int deleteByPosition(int pos) {
		Node temp=head;
		
		if(pos==1) {
			head=temp.next;
			temp.next=null;
			return temp.data;
		}
		
		else {
			Node prev=null;
			int count=0;
			
			for(int i=0;temp.next!=null && i<pos-1;i++) {
				prev=temp;
				temp=temp.next;
			}
			prev.next=temp.next;
			temp.next=null;
			return temp.data;
		}
		
	}
		
}
	
