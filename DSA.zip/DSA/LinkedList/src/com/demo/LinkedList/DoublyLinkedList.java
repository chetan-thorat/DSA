package com.demo.LinkedList;

public class DoublyLinkedList {
	Node head;
	class Node{
		int data;
		Node prev;
		Node next;
		
		public Node(int val){
			this.data = val;
			this.prev=null;
			this.next=null;
		}
	}
	public DoublyLinkedList() {
		head = null;
	}
	
	public void addData(int val) {
		Node newNode=new Node(val);
		if(head==null) {
			head=newNode;
		}else {
			Node temp=head;
			while(temp.next!=null) {
				temp=temp.next;
			}
			newNode.next=temp.next;
			newNode.prev=temp;
			temp.next=newNode;
						
		}
	}
	public void displayData() {
		if(head==null) {
			System.out.println("list is empty");
		}
		else {
			Node temp=head;
			while(temp!=null) {
				System.out.print(temp.data+",  ");
				temp=temp.next;
			}
			System.out.println();
		}
	}
	
	
	public void displayDataReverse() {
		if(head==null) {
			System.out.println("list is empty");
		}else {
			Node temp=head;
			while(temp.next!=null) {
				temp=temp.next;
			}
			while(temp!=null) {
				System.out.print(temp.data+",  ");
				temp=temp.prev;
			}
			
		}
		System.out.println();
	}
	
	
	
	public void addByValue(int num,int value) {
		if(head==null) {
			System.out.println("list is empty");
		}else {
			Node newNode=new Node(num);
			//add at the first position
			if(head.data==value) {
				newNode.next=head;
				head.prev=newNode;
				head=newNode;
			}else {
				Node temp=head;
				while(temp.next!=null && temp.data!=value) {
					temp=temp.next;
				}
				if(temp.data==value) {
					newNode.next=temp.next;
					newNode.prev=temp;
					 
					//if we are adding in between
					if(temp.next!=null) {
						temp.next.prev=newNode;
						temp.next=newNode;
					}
					
				}
			}
			
		}
	}
	
	
	public void deleteByValue(int val) {
		if(head==null) {
			System.out.println("list is empty");
		}
		else {
			//delete from first element
			if(val==head.data) {
				head=head.next;
				head.prev=null;
				
			}
			else {
				Node temp=head;
				while(temp.data!=val) {
					temp=temp.next;
				}
				
				// delete middle or second last element
				if(temp.data==val && temp.next!=null) {
					temp.prev.next = temp.next;
					temp.next.prev = temp.prev;
					temp.next=null;
					temp.prev=null;
				}
				else {
					//delete last element if temp.next==null
					temp.prev.next=temp.next;
					temp.prev=null;
				}
			}
		}
		System.out.println();
	}
	
	//Sum of all elements
	public int sumElements() {
		int sumCount=0;
		if(head==null) {
			System.out.println("list is empty");
		}
		else {
			Node temp=head;
			while(temp!=null) {
				sumCount = sumCount + temp.data;
				temp=temp.next;
			}
		}
		return sumCount;
	}
}
