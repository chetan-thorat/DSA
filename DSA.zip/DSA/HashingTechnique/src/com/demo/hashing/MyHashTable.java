package com.demo.hashing;

public class MyHashTable {
		Node[] heads;
		class Node{
			int data;
			Node next;
			public Node(int val) {
				this.data=val;
				this.next=null;
			}
		}
		
		public MyHashTable() {
			heads=new Node[5];
		}
		
		public MyHashTable(int size) {
			heads=new Node[size];
		}
		public boolean isEmpty(int pos) {
			
			return heads[pos]==null;
		}
		
		//inserting the elements
		public void insertData(int val) {
			Node newNode=new Node(val);
			int pos=val%heads.length;
			if(heads[pos]==null) {
				heads[pos]=newNode;
			}else {
				newNode.next=heads[pos];
				heads[pos]=newNode;
			}
		}
		
		//search the data
		public boolean searchData(int val) {
			int pos=val%heads.length;
			if(heads[pos]==null) {
				System.out.println("Bucket is empty");
				return false;
			}else {
				Node temp=heads[pos];
				while(temp!=null) {
					if(temp.data==val) {
						System.out.println(val+" exists on pos --> "+pos);
						System.out.println();
						return true;
					}
					temp=temp.next;
				}
				System.out.println("Element not found");
				System.out.println();
				return false;
			}
		
		}
		
		
		//display function
		public void display() {			
			for(int i=0;i<heads.length;i++) {
				Node temp=heads[i];
				System.out.print("pos-->" +i+"|");
				while(temp!=null) {
					System.out.print("--->"+temp.data);
					temp=temp.next;
				}
				System.out.println();
			}
			System.out.println();
		}
		
		
		// sum of each elements for each buckets..
		public void displaySum() {	
			System.out.println("total sum is");
			for(int i=0;i<heads.length;i++) {
				Node temp=heads[i];
				System.out.print("pos-->" +i+"|");
				int sum=0;
				while(temp!=null) {
					sum = sum + temp.data;
					temp=temp.next;
				}
				System.out.println("--> "+sum);
			}
			System.out.println();
		}
		
		// delete elements from the bucket position
		public int deleteElement(int pos) {
			Node temp=heads[pos];
			System.out.print("pos-->" +pos+"|");
			
			if(heads[pos]==null) {
				System.out.println(pos+" bucket is empty");
				return -1;
			}
			else { 
				// first elements will be deleted
				heads[pos]=temp.next;
				temp.next=null;
				return temp.data;
			}
			
		}
} 
