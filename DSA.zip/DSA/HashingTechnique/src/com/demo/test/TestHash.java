package com.demo.test;

import com.demo.hashing.MyHashTable;

public class TestHash {

	public static void main(String[] args) {
		MyHashTable ht=new MyHashTable();
		
		ht.insertData(10);
		ht.insertData(22);
		ht.insertData(31);
		ht.insertData(46);
		ht.insertData(587);
		ht.insertData(11);
		ht.insertData(201);
		ht.insertData(320);
		ht.insertData(440);
		ht.insertData(530);
		ht.insertData(204);
		ht.insertData(307);
		ht.insertData(409);
		ht.insertData(555);	
		ht.insertData(35);
		ht.insertData(8);
		ht.insertData(50);
		
		
		ht.display();
		
		ht.searchData(31);
		ht.displaySum();
		
		while(ht.isEmpty(1)==false) {
			System.out.println(ht.deleteElement(1));
			}
		
		
	}
}
