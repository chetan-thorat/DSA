package com.demo.test;

import com.demo.graph.AdjacencyList;

public class TestAdjacenctList {

	public static void main(String[] args) {
		AdjacencyList al = new AdjacencyList(4);
		al.addGraph();
		al.display();
		al.dfsTraversal(0);
		al.bfsTraversal(0);
	}

}
