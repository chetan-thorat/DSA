package com.demo.test;

import com.demo.graph.AdjacencyMatrix;

public class TestAdjacencyMatrix {

	public static void main(String[] args) {
		AdjacencyMatrix am= new AdjacencyMatrix(4);
		am.addGraph();
		am.display();
	}

}
