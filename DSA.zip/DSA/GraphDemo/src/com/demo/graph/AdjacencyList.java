package com.demo.graph;

import java.util.Arrays;
import java.util.Scanner;

public class AdjacencyList {
	Node[] heads;
	class Node{
		int data;
		Node next;
		
		public Node(int val) {
			this.data=val;
			this.next=null;
		}
		
	}
	public AdjacencyList(int size) {
		heads = new Node[size];
	}
	
	public void addGraph() {
		Scanner sc =new Scanner(System.in);
		for(int i=0;i<heads.length;i++) {
			for(int j=0;j<heads.length;j++) {
				System.out.println("edge "+i+"----> "+j+" :");
				int num=sc.nextInt();
				
				if(num==1) {
					Node newNode = new Node(j);
					if(heads[i]==null) {
						heads[i]=newNode;
					}
					else {
						newNode.next=heads[i];
						heads[i]=newNode;
					}
				}
				
			}
		}
	}
	
	
	public void display() {
		for(int i=0;i<heads.length;i++) {
			System.out.println("Node :"+i+"-->");
			Node temp=heads[i];
			while(temp!=null) {
				System.out.print(temp.data+"--->");
				temp=temp.next;
			}
			System.out.print("null\n");
		}
	}
	
	public void dfsTraversal(int n) {
		
		//stack 
		MyStackGeneric<Integer> myStack = new MyStackGeneric<Integer>();
		boolean[] visited=new boolean[heads.length];
		//starting node 
		myStack.push(n);
		//final array to print
		int[] mydfs= new int[heads.length];
		
		//assign all data to false
		for(int i=0;i<heads.length;i++) {
			visited[i]=false;
		}
		
		//this work like indexing for final array
		int count=0;
		
		while(!myStack.isEmpty()) {
			int d=myStack.pop();
			
			//check pop element visited or not
			if(!visited[d]) {
				visited[d]=true;
				mydfs[count]=d;
				count++;
				
				Node temp=heads[d];
				
				//push all adjacent elements of pop element in stack 
				while(temp!=null) {
					if(!visited[temp.data]) {
					myStack.push(temp.data);
					}
					temp=temp.next;
				}
				
				myStack.displayData();
				System.out.println("-------------------");
			}
			
		}
		System.out.println(Arrays.toString(mydfs));
	}
	
	
	
		public void bfsTraversal(int n) {
		//list
		QueueList ql=new QueueList();
		boolean[] visited=new boolean[heads.length];
		//starting node 
		ql.enQueue(n);
		//final array to print
		int[] mydfs= new int[heads.length];
		

		
		
		
		//assign all data to false
		for(int i=0;i<heads.length;i++) {
			visited[i]=false;
		}
		
		//this work like indexing for final array
		int count=0;
		
		while(!ql.isEmpty()) {
			int d=ql.deQueue();
			
			//check dequeue element visited or not
			if(!visited[d]) {
				visited[d]=true;
				mydfs[count]=d;
				count++;
				
				Node temp=heads[d];
				
				//enqueue all adjacent elements of dequeue element in list
				while(temp!=null) {
					if(!visited[temp.data]) {
					ql.enQueue(count);
					}
					temp=temp.next;
				}
				
				ql.display();
				System.out.println("-------------------");
			}
			
		}
		System.out.println(Arrays.toString(mydfs));
	}
	
}
