package com.demo.graph;

public class MyStackGeneric<T> {
	Node top;
	class Node{
		T data;
		Node next;
		
		public Node(T val) {
			this.data=val;
			this.next=null;
		}
	}
	
	public boolean isEmpty() {
		return top==null;
	}
	public void push(T val) {
		Node newNode = new Node(val);
		if(!isEmpty()) {
			newNode.next=top;
		}
		top=newNode;
	}
	
	public T pop() {
		if(isEmpty()) {
			System.out.println("Stack is Empty");
			return null;
		}
		else {
			Node temp=top;
			top=top.next; //top=temp.next
			temp.next=null;
			return temp.data;	
		}
	}
	
	public void displayData() {
		if(isEmpty()) {
			System.out.println("Stack is Empty");
		}
		else {
			Node temp=top;
			while(temp!=null) {
				System.out.print(temp.data+", ");
				temp=temp.next;
			}
			System.out.println();
		}
	}
	
}
