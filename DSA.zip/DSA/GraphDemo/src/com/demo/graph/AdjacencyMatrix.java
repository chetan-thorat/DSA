package com.demo.graph;

import java.util.Scanner;

public class AdjacencyMatrix {
		
		int[][] graph;
		public AdjacencyMatrix(int v) {
			graph=new int[v][v];
		}
		
		public void addGraph() {
			Scanner sc = new Scanner(System.in);
			for(int i=0;i<graph.length;i++) {
				for(int j=0;j<graph[i].length;j++) {
					System.out.println("row :"+i+"   col:"+j);
					graph[i][j]=sc.nextInt();
				}
			}
		}
		
		public void display() {
			for(int i=0;i<graph.length;i++) {
				for(int j=0;j<graph[i].length;j++) {
					System.out.print(graph[i][j]+" ");
					
				}
				System.out.println();
			}
			
		}
		
}
