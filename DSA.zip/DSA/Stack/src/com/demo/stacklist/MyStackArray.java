package com.demo.stacklist;

public class MyStackArray {
	int[] arr;
	int top;
	
	public MyStackArray() {
		arr= new int[5];
		top=-1;
	}
	
	public boolean isEmpty() {
		return top==-1;
	}
	public boolean isFull() {
		return top==arr.length-1;
	}
	
	public void push(int val) {
		if(!isFull()) {
			top++;
			arr[top]=val;
			
		}else {
			System.out.println("list is full");
		}
	}
	
	public int pop() {
		if(!isEmpty()) {
			int num=arr[top];
			top--;
			return num;
		}else {
			System.out.println("list is empty");
			return -1;
		}
	}
	
	public void display() {
		if(top==-1) {
			System.out.println("Array is empty");
		}else {
		for(int i=0;i<=top;i++) {
			System.out.print(arr[i]+", ");
		}
		}
		System.out.println();
	}
}
