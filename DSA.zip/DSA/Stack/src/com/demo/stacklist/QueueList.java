package com.demo.stacklist;

public class QueueList {
	Node rear;
	Node front;
	class Node{
			int data;
			Node next;
			
			public Node(int val) {
				this.data=val;
				this.next=null;
			}
		}
	public boolean isEmpty() {
		return front==null;
	}
	
	public void enQueue(int val) {
		Node newNode = new Node(val);
	if(isEmpty()) {
			front = rear = newNode;			
		}
		else {
			rear.next=newNode;
			rear=rear.next;
		}
	}
	
	public int deQueue() {
		if(isEmpty()) {
			System.out.println("List is Empty");
			return -1;
		}else {
		Node temp = front;
		int num = temp.data;
		front=front.next;
		temp.next=null;
		return temp.data;
		}
	}
	public void display() {
		if(isEmpty()) {
			System.out.println("list is empty");
		}else {
		Node temp = front;
		while(temp!=null) {
			System.out.print(temp.data+", ");
			temp=temp.next;
		}
		}
		System.out.println();
	}
}
