package com.demo.stacklist;

public class CircularQueue {
	int[] arr;
	int front,rear;
	
	public CircularQueue() {
		arr=new int[5];
		front=rear=-1;
	}
	
	public CircularQueue(int size) {
		arr=new int[size];
		front=rear=-1;
	}
	
	public boolean isEmpty() {
		if(front==-1) {
			System.out.println("Queue is empty");
			return true;
		}
		return false;
	}
	
	public boolean isFull() {
		if(front==0 && rear==arr.length-1) {
			System.out.println("Queue is full");
			return true;
		}
		else {
			
			if(front == rear+1) {
				System.out.println("Queue is full");
			}
		}
		return false;
	}
	
	
	public boolean enQueue(int val) {
		if(!isFull()) {
			if(front==-1) {
				front=0;
			}
			
			rear=(rear+1)%arr.length;
			arr[rear]=val;
			System.out.println("added successfully");
			return true;
		}
		
		return false;
	}
	
	
	public int deQueue() {
		if(isEmpty()) {
			
			return -1;
		}
		
		else {
			int num=arr[front];
			if(front==rear) {
				rear=front=-1;
			}
			else {
				front=(front+1)%arr.length;
			}
			return num;
		}
	}
}
