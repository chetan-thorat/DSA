package com.demo.test;

import java.util.Arrays;

import com.demo.stacklist.MyStackGeneric;

public class ReverseStringGenericStack {

	public static void main(String[] args) {
		MyStackGeneric<String> gs = new MyStackGeneric<>();
		
		
		// To reverse string with space using character ( charAt())
		// Before run this code change generic type to "Character"
		
//		String mystr= "CDAC IET Pune";
//		
//		for(int i=0;i<mystr.length();i++) {
//			Character ch = mystr.charAt(i);
//			gs.push(ch);
//		}
//		
//		while(!gs.isEmpty()) {
//			System.out.print(gs.pop());
//		}
//	}
		
		//To reverse string with words using String by split function
		// Before run this code change generic type to "String" 
		String mystr= "CDAC IET Pune";
		
		String[] arr = mystr.split(" ");
		
		for(int i=0;i<arr.length;i++) {
			gs.push(arr[i]);
		}
		
		while(!gs.isEmpty()) {
			System.out.print(gs.pop()+" ");
		}
	}

}
