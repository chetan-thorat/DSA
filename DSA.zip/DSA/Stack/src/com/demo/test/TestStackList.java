package com.demo.test;

import com.demo.stacklist.StackList;

public class TestStackList {
	public static void main(String[] args) {
		StackList sl = new StackList();
		sl.push(30);
		sl.push(20);
		sl.push(10);
		System.out.println(sl.pop());
		System.out.println(sl.pop());
		System.out.println(sl.pop());
		System.out.println(sl.pop());
		
		
		
}
}
