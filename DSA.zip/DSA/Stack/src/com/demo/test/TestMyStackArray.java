package com.demo.test;

import com.demo.stacklist.MyStackArray;

public class TestMyStackArray {

	public static void main(String[] args) {
		MyStackArray sa =new MyStackArray();
		
		sa.push(10);
		sa.push(20);
		sa.push(30);
		sa.push(40);

		
		sa.display();
		
		while(!sa.isEmpty()) {
			System.out.println(sa.pop());
		}
		sa.display();
	}
	

}
