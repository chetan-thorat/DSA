package com.demo.test;

import com.demo.stacklist.CircularQueue;

public class TestCircularQueue {

	public static void main(String[] args) {
		CircularQueue cq = new CircularQueue();
		cq.enQueue(10);
		cq.enQueue(20);
		cq.enQueue(30);
		cq.enQueue(40);
		cq.enQueue(50);
		cq.deQueue();
		cq.enQueue(60);
		
		
		System.out.println(cq.deQueue());
		System.out.println(cq.deQueue());
		System.out.println(cq.deQueue());
		System.out.println(cq.deQueue());
		System.out.println(cq.deQueue());
		System.out.println(cq.deQueue());
		

	}

}
