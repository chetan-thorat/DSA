package com.demo.test;

import com.demo.stacklist.MyStackGeneric;

public class TestGenericParenthesis {

	public static void main(String[] args) {
		String str1= "{{[]()[]}}}";
		
		boolean status=checkParenthesis(str1);
		if(status) {
			System.out.println("Parenthesis is balanced");
		}else {
			System.out.println("Parenthesis is not balanced");
		}

	}
	
	public static boolean checkParenthesis(String str) {
		MyStackGeneric<Character> sg=new MyStackGeneric<>();
		
		for(int i=0;i<str.length();i++) {
			Character ch=str.charAt(i);
			if(ch=='{' ||ch=='[' || ch=='(') {
				sg.push(ch);
			}else {
				if(sg.isEmpty()) {
					return false;
				}else {
					Character ch1=sg.pop();
					switch(ch) {
					case '}':
						if(ch1!='{') {
							return false;
						}
						break;
					case ']':
						if(ch1!='[') {
							return false;
						}
						break;
					case ')':
						if(ch1!='(') {
							return false;
						}
						break;
					}
				}
			}
		}
		if(sg.isEmpty()) {
			return true;
		}else {
			return false;
		}
	}
}
