package com.demo.test;

import com.demo.stacklist.QueueList;

public class TestQueueList {

	public static void main(String[] args) {
		QueueList ql = new QueueList();
		
		ql.enQueue(10);
		ql.enQueue(20);
		ql.enQueue(30);
		ql.enQueue(40);
		ql.enQueue(50);
		
		ql.display();
		
		System.out.println(ql.deQueue());
		System.out.println(ql.deQueue());
		System.out.println(ql.deQueue());
		System.out.println(ql.deQueue());
		System.out.println(ql.deQueue());
		ql.display();
	}
}
